{-# LANGUAGE TypeOperators, GADTs #-}

-- Load with `stack ghci`
-- using the Linear type branch of GHC
-- https://github.com/tweag/ghc/tree/linear-types

constBad :: x ->. y ->. x
constBad x y = x

const :: x -> y -> x
const x y = x

dub :: x ->. (x, x)
dub x = (x, x)

-- Like a 'Box A' type
data Unrestricted a where
      Unrestricted :: a -> Unrestricted a

dub' :: Unrestricted x ->. (x, x)
dub' (Unrestricted x) = (x, x)
